# Telegram Purchase Bot (Python)

- Country must be selected before payment
- Username is generated from Telegram display name + **2 random digits** (no country prefix)
- Default password is "1"
- Admin approves/rejects screenshots
